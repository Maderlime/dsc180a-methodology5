Save external references here
